﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace button_game
{
    public partial class Form1 : Form
    {

        // This SoundPlayer plays a sound whenever the player hits a wall.
        System.Media.SoundPlayer startSoundPlayer = new System.Media.SoundPlayer(@"C:\Windows\Media\Start_game_wave.wav");

        // This SoundPlayer plays a sound when the player finishes the game.
        System.Media.SoundPlayer finishSoundPlayer = new System.Media.SoundPlayer(@"C:\Windows\Media\End_of_game_wave.wav");

        public Form1()
        {
            InitializeComponent();
            MoveToStart();
        }

        private void panel1_MouseEnter(object sender, EventArgs e)
        {
            MessageBox.Show("Congratulation");
            Close();

        }

        private void MoveToStart()
        {
            Point startingPoint = panel1.Location;
            startingPoint.Offset(10, 10);
            Cursor.Position = PointToScreen(startingPoint);

        }

        private void label2_MouseEnter(object sender, EventArgs e)
        {
            MoveToStart();
        }

        private int flag = 0;

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (flag == 0) 
            {
                label3.Enabled = true;
                label3.Visible = true;
                flag = 1;
            }
            else
            {
                
            }
      
        {
                label3.Enabled = false;
                label3.Visible = false;
                flag = 0;

            }
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Congratulation");
            Close();
        }
    }
}




